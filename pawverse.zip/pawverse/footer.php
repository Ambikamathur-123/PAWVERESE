  <footer class="footer">
    <div>© Pawverse 2024. All rights reserved.</div>
    <div class="footer-links">
      <a href="#">Privacy Policy</a> |
      <a href="#">Terms of Service</a>
    </div>
  </footer>
  <?php wp_footer(); ?>
</body>
</html> 